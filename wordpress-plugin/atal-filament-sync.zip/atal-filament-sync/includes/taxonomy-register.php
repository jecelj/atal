<?php
/**
 * Taxonomy Registration
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'atal_sync_register_taxonomies');

function atal_sync_register_taxonomies()
{
    // Brand Taxonomy
    register_taxonomy('yacht_brand', ['new_yachts', 'used_yachts'], [
        'labels' => [
            'name' => __('Brands', 'atal-sync'),
            'singular_name' => __('Brand', 'atal-sync'),
            'search_items' => __('Search Brands', 'atal-sync'),
            'all_items' => __('All Brands', 'atal-sync'),
            'edit_item' => __('Edit Brand', 'atal-sync'),
            'update_item' => __('Update Brand', 'atal-sync'),
            'add_new_item' => __('Add New Brand', 'atal-sync'),
        ],
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => ['slug' => 'brand'],
    ]);

    // Model Taxonomy
    register_taxonomy('yacht_model', ['new_yachts', 'used_yachts'], [
        'labels' => [
            'name' => __('Models', 'atal-sync'),
            'singular_name' => __('Model', 'atal-sync'),
            'search_items' => __('Search Models', 'atal-sync'),
            'all_items' => __('All Models', 'atal-sync'),
            'edit_item' => __('Edit Model', 'atal-sync'),
            'update_item' => __('Update Model', 'atal-sync'),
            'add_new_item' => __('Add New Model', 'atal-sync'),
        ],
        'hierarchical' => true,
        'show_in_rest' => true,
        'show_admin_column' => true,
        'rewrite' => ['slug' => 'model'],
    ]);
}
